# Escola sem Violência

Website educativo sobre violência física e psicológica entre alunos.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Carregue o ficheiro `index.html` para a pasta principal (raiz) do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Seleccione a branch `main` e a pasta `/ (root)`, depois carregue em **Save**.
6. Aguarde a publicação. O GitHub mostrará o endereço do website na secção Pages.

O website está num único ficheiro HTML e adapta-se a telemóveis e computadores.
